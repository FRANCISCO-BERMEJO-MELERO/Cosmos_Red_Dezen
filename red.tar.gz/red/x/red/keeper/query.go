package keeper

import (
	"red/x/red/types"
)

var _ types.QueryServer = Keeper{}
